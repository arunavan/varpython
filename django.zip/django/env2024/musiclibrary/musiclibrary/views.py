from django.shortcuts import render
from django.http import HttpResponse
#from django.template import loader    
def hello_world(request):
 #  template = loader.get_template('home.html')
   return render(request, "home.html", {})  
  # return HttpResponse(template.render())   //("Hello World! welcome to Django firts project")


def getemi(request):
   return HttpResponse("welcome , youremi amount is 9999")
